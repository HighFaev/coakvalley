# Code in this package from the GOG Galaxy integration for Battle.net
# https://github.com/bartok765/galaxy_blizzard_plugin
# All credits go to bartok765 and contributors
